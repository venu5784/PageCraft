PageCraft Website

Files:
- index.html: the complete PageCraft landing page.

How to preview:
1. Extract this ZIP folder.
2. Open index.html in Chrome or another web browser.

How to publish it:
1. Go to https://app.netlify.com/drop
2. Sign in or create a free Netlify account if prompted.
3. Drag and drop the extracted PageCraft-Website folder (or a folder containing index.html).
4. Netlify will provide a public website URL ending in netlify.app.

Important:
The enquiry form is a demo and does not send/store messages. Add your real WhatsApp, phone, email, or a working form service before using it with customers.
